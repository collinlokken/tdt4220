package com.mygdx.game.model;

public abstract class Model {
}
