### README
Stripa Survivour (SS) game for the course TDT4220

Contributors:
* Henrik Udnes
* Kristian Hansen
* Lars Sorensen
* Vegard Nyeng
* Erlend Haakegaard
* Christopher Løkken
